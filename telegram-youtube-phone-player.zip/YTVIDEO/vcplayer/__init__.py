"""Telegram call player."""
